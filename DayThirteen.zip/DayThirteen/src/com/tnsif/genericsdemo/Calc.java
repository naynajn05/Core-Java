package com.tnsif.genericsdemo;

public class Calc<Number> {
	void add(Number n)
	{
		
	}

}
